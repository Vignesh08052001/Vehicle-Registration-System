package com.sgic.library.services;

import java.util.List;

import com.sgic.library.entities.Book;
import com.sgic.library.entities.Signin;

public interface BookService {
	void saveBook(Book book);// save book
	List<Book> getAllBook();		//	Get All Book
	Book findBookById(String id); // find book by id - bookID
	Book deleteBookById(String id);	//	Delete Book
	void updateBook(Book book);		//	Update Book
	
}
public interface BookService {
	void signin(Signin signin);// save book
	// List<Book> getAllBook();		//	Get All Book
	Book findBookByUsername(String username); // find book by id - bookID
	
	
}