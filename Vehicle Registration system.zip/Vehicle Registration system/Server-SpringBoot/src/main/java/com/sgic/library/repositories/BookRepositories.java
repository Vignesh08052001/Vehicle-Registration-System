package com.sgic.library.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sgic.library.entities.Book;
import com.sgic.library.entities.Signin;


public interface BookRepositories extends JpaRepository<Book, String> {
	Book findBookBybookId(String id);
}
public interface SigninRepositories extends JpaRepository<Signin, String> {
	Book findBookByUsername(String username);
}
