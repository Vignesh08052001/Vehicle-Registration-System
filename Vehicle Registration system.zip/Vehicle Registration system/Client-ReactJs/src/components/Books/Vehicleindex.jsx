import React, { Component } from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import ListVehicle from "./ListVehicle";
import AddVehicle from "./AddVehicle";
import EditVehicle from "./EditVehicle";
import login from "./login";
import signin from "./signin";

class Vehicleindex extends Component {
  render() {
    return (
      <Router>
        <Switch>
          <Route path="/" exact component={AddVehicle} />
          <Route path="/login" exact component={login} />          
          <Route path="/signin" exact component={signin} />        
          <Route path="/ListVehicle" exact component={ListVehicle} />         
          <Route path="/EditVehicle/:id" exact component={EditVehicle} />
          <Route path="/BackBookList" exact component={ListVehicle} />
        </Switch>
      </Router>
    );
  }
}

export default Vehicleindex;
