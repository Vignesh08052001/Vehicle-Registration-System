// import React from 'react';
// import Avatar from '@material-ui/core/Avatar';
// import Button from '@material-ui/core/Button';
// import CssBaseline from '@material-ui/core/CssBaseline';
// import TextField from '@material-ui/core/TextField';
// import FormControlLabel from '@material-ui/core/FormControlLabel';
// import Checkbox from '@material-ui/core/Checkbox';
// import Link from '@material-ui/core/Link';
// import Grid from '@material-ui/core/Grid';
// import Box from '@material-ui/core/Box';
// import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
// import Typography from '@material-ui/core/Typography';
// import { makeStyles } from '@material-ui/core/styles';
// import Container from '@material-ui/core/Container';
// class login extends React.Component{
//     routeAddVehicle() {
//         let path = `/ListVehicle`;
//         this.props.history.push(path);
//       }
//       routeEditVehicle(id) {
//         // let pathedit = `/EditVehicle`;
//         // this.props.history.push(pathedit);
//         this.props.history.push(`/EditVehicle/${id}`);
//       }
//       deleteBook(id) {
//         axios
//           .delete("http://localhost:8080/library/deleteBook/" + id)
//           .then(response => {
//             console.warn("Vehicle Service is working");
//             this.refreshBook(response);
    
//             alert("Vehicle deleted successfully");
//           });
//       }
// const useStyles = makeStyles((theme) => ({
//   paper: {
//     marginTop: theme.spacing(8),
//     display: 'flex',
//     flexDirection: 'column',
//     alignItems: 'center',
//   },
//   avatar: {
//     margin: theme.spacing(1),
//     backgroundColor: theme.palette.secondary.main,
//   },
//   form: {
//     width: '100%', // Fix IE 11 issue.
//     marginTop: theme.spacing(1),
//   },
//   submit: {
//     margin: theme.spacing(3, 0, 2),
//   },
// }));

// export default function SignIn() {
//   const classes = useStyles();

//   return (
//     <Container component="main" maxWidth="xs">
//       <CssBaseline />
//       <div className={classes.paper}>
//         <Avatar className={classes.avatar}>
//           <LockOutlinedIcon />
//         </Avatar>
//         <Typography component="h1" variant="h5">
//           Sign in
//         </Typography>
//         <form className={classes.form} noValidate>
//           <TextField
//             variant="outlined"
//             margin="normal"
//             required
//             fullWidth
//             id="email"
//             label="Email Address"
//             name="email"
//             autoComplete="email"
//             autoFocus
//           />
//           <TextField
//             variant="outlined"
//             margin="normal"
//             required
//             fullWidth
//             name="password"
//             label="Password"
//             type="password"
//             id="password"
//             autoComplete="current-password"
//           />
//           <FormControlLabel
//             control={<Checkbox value="remember" color="primary" />}
//             label="Remember me"
//           />
//           <Button
//             type="submit"
//             fullWidth
//             variant="contained"
//             color="primary"
//             className={classes.submit}
//           >
//             Sign In
//           </Button>
//           <Grid container>
//             <Grid item xs>
//               <Link href="#" variant="body2">
//                 Forgot password?
//               </Link>
//             </Grid>
//             <Grid item>
//               <Link href="#" variant="body2">
//                 {"Don't have an account? Sign Up"}
//               </Link>
//             </Grid>
//           </Grid>
//         </form>
//       </div>
      
//     </Container>
//   );
// }
// }
// export default login;
import React, { Component } from "react";
import axios from "axios";
import { Formik, Form, Field } from "formik";
import "react-s-alert/dist/s-alert-default.css";
import "react-s-alert/dist/s-alert-css-effects/slide.css";

class AddVehicle extends Component {
  constructor(props) {
    super(props);
    this.state = { books: [], name: null };
    this.state = { bookId: "", bookISBN: "", bookName: "" };
    this.handleChangeid = this.handleChangeid.bind(this);
    this.handleChangename = this.handleChangename.bind(this);
    this.handleChangeisbn = this.handleChangeisbn.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.routeListVehicle = this.routeListVehicle.bind(this);
    this.routesignin = this.routesignin.bind(this);
  }

  //GET ID METHOD
  handleChangeid(e) {
    this.setState({
      txtbookid: e.target.value
    });
  }

  //GET ISBN METHOD
  handleChangeisbn(f) {
    this.setState({
      txtbookisbn: f.target.value
    });
  }

  //GET NAME METHOD
  handleChangename(g) {
    this.setState({
      txtbookname: g.target.value
    });
  }

  //ON SUBMIT FORM METHOD
  onSubmit(e) {
    e.preventDefault();
    const save = {
      bookId: this.state.txtbookid,
      bookISBN: this.state.txtbookisbn,
      bookName: this.state.txtbookname
    };
    axios.post("http://localhost:8080/library/saveBook", save).then(res => {
      if (res.status === 200) {
        alert("Log in successful!!");
        window.location.reload();
      }
    });

    this.setState({
      bookId: "",
      bookISBN: "",
      bookName: ""
    });

    this.routeListVehicle();
  }

  //BACK FUNCTION TO BOOK lIST
  routeListVehicle() {
    let path = `/ListVehicle`;
    this.props.history.push(path);
  }
  routesignin() {
    let path = `/signin`;
    this.props.history.push(path);
  }

  //RENDERING PATTERN
  render() {
    return (          
      <div className="col-sm-12">         
        <br /><br /><br />
        <div className="container" >
          <br />
          <button
            className="btn btn-primary"
            type="submit"
            onClick={this.routeListVehicle}
          >
            <i className="fa fa-arrow-circle-left  "> Back</i>
          </button>
          <h3 align="center">LOGIN</h3>
        </div>

        <Formik>    
          <Form className="container" onSubmit={this.onSubmit}>
            <fieldset>
              <label>USERNAME:</label>
              <Field
                className="form-control"
                type="email"
                name="emailid"
                value={this.state.emailid}
                onChange={this.handleChangeid}
                placeholder="Email.."
              />
            </fieldset>
              
            <fieldset className="form-group">
            <label>PASSWORD</label>
              <Field
                className="form-control"
                type="password"
                name="password"
                value={this.state.password}
                onChange={this.handleChangename}
                placeholder="Name.."
              />
            </fieldset>

            
            
            <button
              className="btn btn-success"
              value="Submit"
              type="submit"
              align="center"
            >
              <i className="fa fa-plus">Submit</i>
            </button>
            &nbsp; &nbsp;
            <button
              className="btn btn-danger"
              type="reset"
              value="reset"
              align="center"
            >
              <i className="fa fa-location-arrow">Reset</i>
            </button>&nbsp;
            <button
              className="btn btn-success"
              value="Submit"
              type="submit"
              align="center"
              onClick={this.routesignin}
             
            >
              <i className="fa fa-plus"> Sign up</i>
            </button>
            <br />
            &nbsp; &nbsp; &nbsp;
          </Form>
        </Formik>
      </div>
      
    );
  }
}

export default AddVehicle;
