import React, { Component } from "react";
import axios from "axios";
import { Formik, Form, Field } from "formik";
import "react-s-alert/dist/s-alert-default.css";
import "react-s-alert/dist/s-alert-css-effects/slide.css";

class AddVehicle extends Component {
  constructor(props) {
    super(props);
    this.state = { signin: [] };
    this.state = { name: "", username: "", password: "",passcode:"" };
    this.onSubmit = this.onSubmit.bind(this);
    this.routeListVehicle = this.routeListVehicle.bind(this);
    this.routelogin=this.routelogin.bind(this);
    this.handleChangename = this.handleChangename.bind(this);
    this.handleChangeusername = this.handleChangeusername.bind(this);
    this.handleChangepassword = this.handleChangepassword.bind(this);
    this.handleChangepasscode = this.handleChangepasscode.bind(this);
  }

  //GET ID METHOD
  handleChangename(e) {
    this.setState({
      name1: e.target.value
    });
  }

  // //GET ISBN METHOD
  handleChangeusername(f) {
    this.setState({
      username1: f.target.value
    });
  }

  // //GET NAME METHOD
  handleChangepassword(g) {
    this.setState({
      password1: g.target.value
    });
  }
  handleChangepasscode(h) {
    this.setState({
      passcode1: h.target.value
    });
  }

  //ON SUBMIT FORM METHOD
  onSubmit(e) {
    e.preventDefault();
    const save = {
      name: this.state.name1,
      username: this.state.username1,
      password: this.state.password1,
      passcode: this.state.passcode1
    };
    axios.post("http://localhost:8080/library/saveBook", save).then(res => {
      if (res.status === 200) {
        alert("Signuped successfully.!");
        window.location.reload();
      }
    });

    this.setState({
      name1: "",
      username1: "",
      password1: "",
      passcode1:""
    });

    this.routelogin();
  }

  //BACK FUNCTION TO BOOK lIST
  routeListVehicle() {
    let path = `/login`;
    this.props.history.push(path);
  }
  routelogin() {
    let path = `/login`;
    this.props.history.push(path);
  }

  //RENDERING PATTERN
  render() {
    return (       
      <div className="col-sm-12">         
        <br /><br /><br />
        <div className="container" >
          <br />
          <button
            className="btn btn-primary"
            type="submit"
            onClick={this.routeListVehicle}
          >
            <i className="fa fa-arrow-circle-left  "> Back</i>
          </button>
          <h3 align="center">SIGNUP</h3>
        </div>

        <Formik>
          <Form className="container" onSubmit={this.onSubmit}>
          <fieldset>
              <label>NAME:</label>
              <Field
                className="form-control"
                type="text"
                name="name1"
                value={this.state.name1}
                // onChange={this.handleChangename}
                placeholder="Name.."
              />
            </fieldset>
              
            <fieldset>
              <label>USERNAME:</label>
              <Field
                className="form-control"
                type="email"
                name="username1"
                value={this.state.username1}
                // onChange={this.handleChangeusername}
                placeholder="Username.."
              />
            </fieldset>
              
            <fieldset className="form-group">
            <label>PASSWORD</label>
              <Field
                className="form-control"
                type="password"
                name="password1"
                value={this.state.password1}
                // onChange={this.handleChangepassword}
                placeholder="Password.."
              />
            </fieldset>
            <fieldset>
              <label>PASSCODE:</label>
              <Field
                className="form-control"
                type="text"
                
                name="passcode1"
                value={this.state.passcode1}
                // onChange={this.handleChangepasscode}
                placeholder="Passcode.."
              />
            </fieldset>
            <br/>            
            <button
              className="btn btn-success"
              value="Submit"
              type="submit"
              align="center"
            >
              <i className="fa fa-plus"> Signup</i>
            </button>
            &nbsp; &nbsp;
            <button
              className="btn btn-danger"
              type="reset"
              value="reset"
              align="center"
            >
              <i className="fa fa-location-arrow"> Cancel</i>
            </button>
            &nbsp;            
            <br />
            &nbsp; &nbsp; &nbsp;
          </Form>
        </Formik>
      </div>      
    );
  }
}

export default AddVehicle;