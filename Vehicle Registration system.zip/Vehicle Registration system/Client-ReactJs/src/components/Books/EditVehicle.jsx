import React, { Component } from "react";
import axios from "axios";
import { Formik, Form, Field } from "formik";
class EditVehicle extends Component {
  constructor(props) {
    super(props);
    this.state = { books: [], name: null };
    this.state.books = {
      bookId: this.props.match.params.id,
      bookISBN: "",
      bookName: ""
    };
    this.handleChangeid = this.handleChangeid.bind(this);
    this.handleChangename = this.handleChangename.bind(this);
    this.handleChangeisbn = this.handleChangeisbn.bind(this);
    this.routeListVehicle = this.routeListVehicle.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  componentDidMount() {
    axios
      .get(
        "http://localhost:8080/library/geBookById/" + this.props.match.params.id
      )
      .then(result => {
        console.table(result);
        this.setState({
          id: result.data.bookId,
          txtbookisbn: result.data.bookISBN,
          txtbookname: result.data.bookName
        });
      });
  }

  //GET ID METHOD
  handleChangeid(e) {
    this.setState({
      txtbookid: e.target.value
    });
  }

  //GET ISBN METHOD
  handleChangeisbn(f) {
    this.setState({
      txtbookisbn: f.target.value
    });
  }

  //GET NAME METHOD
  handleChangename(g) {
    this.setState({
      txtbookname: g.target.value
    });
  }

  //ON SUBMIT FORM METHOD
  onSubmit(e) {
    e.preventDefault();

    const update = {
      bookId: this.state.id,
      bookISBN: this.state.txtbookisbn,
      bookName: this.state.txtbookname
    };
    axios.put("http://localhost:8080/library/updateBook", update).then(res => {
      if (res.status === 200) {
        alert("Vehicle update successfully.");
        window.location.reload();
      }
    });

    this.routeListVehicle();
  }

  //BACK BOOK LIST
  routeListVehicle() {
    let path = `/`;
    this.props.history.push(path);
  }

  render() {
    return (
      <div className="col-sm-12">
        <div className="container">
          <br />
          <button
            className="btn btn-primary"
            type="submit"
            onClick={this.routeListVehicle}
          >
            <i className="fa fa-arrow-circle-left  "> Back</i>
          </button>
          <h3 align="center">EDIT-VEHICLES</h3>
        </div>

        <Formik>
          <Form className="container" onSubmit={this.onSubmit}>
            <fieldset>
              <label>Vehicle number</label>
              <Field
                className="form-control"
                type="text"
                name="id"
                value={this.state.id}
                onChange={this.handleChangeid}
                placeholder="Vehicle number.."
                disabled
              />
            </fieldset>
            <fieldset className="form-group">
              <label>Name</label>
              <Field
                className="form-control"
                type="text"
                name="txtbookname"
                value={this.state.txtbookname}
                onChange={this.handleChangename}
                placeholder="Name.."
              />
            </fieldset>
            <fieldset className="form-group">
              <label>Address</label>
              <Field
                className="form-control"
                type="text"
                name="txtbookisbn"
                value={this.state.txtbookisbn}
                onChange={this.handleChangeisbn}
                placeholder="Address.."
              />
            </fieldset>
            
            <button
              className="btn btn-success"
              value="Submit"
              type="submit"
              align="center"
            >
              <i className="fa fa-plus"> Update</i>
            </button>
            &nbsp;
            <button
              className="btn btn-danger"
              type="reset"
              onClick={this.routeListVehicle}
              align="center"
            >
              <i className="fa fa-location-arrow"> cancel</i>
            </button>
            <br />
            &nbsp; &nbsp; &nbsp;
          </Form>
        </Formik>
      </div>
    );
  }
}

export default EditVehicle;
