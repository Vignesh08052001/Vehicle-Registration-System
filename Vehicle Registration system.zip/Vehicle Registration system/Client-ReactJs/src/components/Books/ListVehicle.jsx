import React from "react";
import axios from "axios";
import "@fortawesome/fontawesome-free/css/all.min.css";

class ListVehicle extends React.Component {
  constructor(props) {
    super(props);
    this.state = { books: [], name: null, query: "" };
    this.deleteBook = this.deleteBook.bind(this);
    this.refreshBook = this.refreshBook.bind(this);
    this.routeAddVehicle = this.routeAddVehicle.bind(this);
  }

  //REDIRECT PAGE
  routeAddVehicle() {
    let path = `/`;
    this.props.history.push(path);
  }

  componentDidMount() {
    axios.get("http://localhost:8080/library/findAll").then(response => {
      this.setState({ books: response.data });
      //console.table(response.data);
      console.warn("Vehicle Service is working");
    });

    // CALLING REFRESH BOOK METHOD
    this.refreshBook();
  }

  //REFRESH BOOK METHOD
  refreshBook() {
    axios.get("http://localhost:8080/library/findAll").then(response => {
      console.warn("Refresh Service is working");
      this.setState({ books: response.data });
    });
  }
  /*END OF REFRESH METHOD */

  //Route Edit BOOK
  routeEditVehicle(id) {
    // let pathedit = `/EditVehicle`;
    // this.props.history.push(pathedit);
    this.props.history.push(`/EditVehicle/${id}`);
  }

  //DELETE-METHOD 1 = WORKING
  deleteBook(id) {
    axios
      .delete("http://localhost:8080/library/deleteBook/" + id)
      .then(response => {
        console.warn("Vehicle Service is working");
        this.refreshBook(response);

        alert("Vehicle deleted successfully");
      });
  }
  /*END OF DELETE METHOD = 1*/

  render() {
    return (
      <div className="col-sm-12">
        <br />

        <h3 align="center">LIST-VEHICLES</h3>
        <br />
        <div className="container" onLoad={this.refreshBook}>
        <button
            className="btn btn-primary"
            type="submit"
            onClick={this.routeAddVehicle}
          >
            <i className="fa fa-arrow-circle-left  "> Back</i>
          </button>
          <br />

          <br />

          <table className="table">
            <thead>
              <tr>
                <th>VEHICLE-NUMBER</th>
                <th>NAME</th>
                <th>ADDRESS</th>
                <th> &nbsp; &nbsp; &nbsp; &nbsp;ACTION</th>
              </tr>
            </thead>
            <tbody>
              {this.state.books.map(book => (
                <tr key={book.bookId}>
                  <td>{book.bookId}</td>  
                  <td>{book.bookISBN}</td>
                  <td>{book.bookName}</td>
                  <td>
                    <button className="btn btn-primary" type="submit">
                      <i
                        className="fa fa-edit"
                        onClick={() => this.routeEditVehicle(book.bookId)}
                      >
                        Edit
                      </i>
                    </button>
                    &nbsp;
                    <button
                      className="btn btn-danger"
                      //NORMAL CALL
                      // onClick={() => this.deleteBook(book.bookId)}

                      //CALL WITH CONFIRM MESSAGE
                      onClick={() =>
                        window.confirm(
                          "Are you sure you wish to delete this vehicle? "
                        ) && this.deleteBook(book.bookId)
                      }
                    >
                      <i className="fa fa-trash"> Delete</i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default ListVehicle;
