import React, { Component } from "react";
import "./App.css";
// import ListVehicles from "./components/Books/ListVehicle";
// import AddVehicle from "./components/Books/AddVehicle";
import Vehicleindex from "./components/Books/Vehicleindex";
import MiniDrawer from "./components/Test/Test";
class App extends Component {
  render() {
    return (
      <div>
        <MiniDrawer />
        {/* <Search /> */}
        <Vehicleindex />
        {/* <SearchAppBar /> */}
        {/* <ListVehicles /> */}
        {/* <AddVehicle /> */}
        {/* <signin />*/}
        {/* <login/> */}
      </div>
    );
  }
}

export default App;
